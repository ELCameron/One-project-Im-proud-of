package com.example.myapplication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;

public class MainActivity3 extends AppCompatActivity {

    private TextInputEditText listNameInput, itemInput;
    private ArrayList<String> items = new ArrayList<>();
    private ItemsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        // Initialize views
        listNameInput = findViewById(R.id.listNameInput);
        itemInput = findViewById(R.id.itemInput);
        Button addItemButton = findViewById(R.id.addItemButton);
        Button saveListButton = findViewById(R.id.saveListButton);

        // Setup RecyclerView with proper scrolling
        RecyclerView recyclerView = findViewById(R.id.itemsRecyclerView);
        recyclerView.setHasFixedSize(false); // Critical for dynamic lists

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        // Add divider between items (optional)
        recyclerView.addItemDecoration(
                new DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
        );

        adapter = new ItemsAdapter(items);
        recyclerView.setAdapter(adapter);

        // Add item button click
        addItemButton.setOnClickListener(v -> {
            String item = itemInput.getText().toString().trim();
            if (!item.isEmpty()) {
                items.add(item);
                adapter.notifyItemInserted(items.size() - 1);
                itemInput.getText().clear();
                // Auto-scroll to new item
                recyclerView.smoothScrollToPosition(items.size() - 1);
            } else {
                Toast.makeText(this, "Please enter an item", Toast.LENGTH_SHORT).show();
            }
        });

        // Save list button click
        saveListButton.setOnClickListener(v -> {
            String listName = listNameInput.getText().toString().trim();
            if (listName.isEmpty()) {
                Toast.makeText(this, "Please name your list", Toast.LENGTH_SHORT).show();
            } else if (items.isEmpty()) {
                Toast.makeText(this, "Please add at least one item", Toast.LENGTH_SHORT).show();
            } else {
                saveShoppingList(listName, items);
                Toast.makeText(this, "List saved!", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    private void saveShoppingList(String listName, ArrayList<String> items) {
        SharedPreferences prefs = getSharedPreferences("ShoppingLists", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(listName, String.join(",", items));
        editor.apply();
    }
}