package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Set welcome message
        setWelcomeMessage();

        // Set up buttons
        Button btnNewList = findViewById(R.id.btnNewList);
        Button btnViewLists = findViewById(R.id.btnViewLists);
        Button btnAllergyInfo = findViewById(R.id.btnAllergyInfo);

        btnNewList.setOnClickListener(v ->
                startActivity(new Intent(this, MainActivity3.class)));

        btnViewLists.setOnClickListener(v ->
                startActivity(new Intent(this, MainActivity4.class)));

        btnAllergyInfo.setOnClickListener(v -> showAllergyInfo());
    }

    private void setWelcomeMessage() {
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String firstName = prefs.getString("firstName", "User");
        TextView welcomeText = findViewById(R.id.welcomeText);
        welcomeText.setText(String.format("Welcome %s!", firstName));
    }

    private void showAllergyInfo() {
        try {
            // Open the file
            InputStream is = getAssets().open("allergy_data.txt");

            // Read the file
            StringBuilder sb = new StringBuilder();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String line;

            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            reader.close();

            // Show dialog
            new AlertDialog.Builder(this)
                    .setTitle("Allergy Information")
                    .setMessage(sb.toString())
                    .setPositiveButton("OK", null)
                    .show();

        } catch (IOException e) {
            Toast.makeText(this, "Error: Allergy file not found", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
}