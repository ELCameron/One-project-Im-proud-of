package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private TextInputEditText firstNameInput, lastNameInput, emailInput, zipcodeInput;
    private TextInputLayout emailLayout, zipcodeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firstNameInput = findViewById(R.id.editTextFirstName);
        lastNameInput = findViewById(R.id.editTextLastName);
        emailInput = findViewById(R.id.editTextEmail);
        zipcodeInput = findViewById(R.id.editTextZipcode);
        emailLayout = findViewById(R.id.emailInputLayout);
        zipcodeLayout = findViewById(R.id.zipcodeInputLayout);
        Button signUpButton = findViewById(R.id.buttonSignUp);

        signUpButton.setOnClickListener(v -> {
            if (validateInputs()) {
                // Save user data
                saveUserData();

                // Show confirmation
                Toast.makeText(this, "Welcome! Let's go shopping!", Toast.LENGTH_SHORT).show();

                // Navigate to MainActivity2
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);

                finish();
            }
        });
    }

    private void saveUserData() {
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        prefs.edit()
                .putString("firstName", Objects.requireNonNull(firstNameInput.getText()).toString().trim())
                .putString("lastName", Objects.requireNonNull(lastNameInput.getText()).toString().trim())
                .putString("email", Objects.requireNonNull(emailInput.getText()).toString().trim())
                .putString("zipcode", Objects.requireNonNull(zipcodeInput.getText()).toString().trim())
                .apply();
    }

    private boolean validateInputs() {
        boolean isValid = true;

        // First name validation
        if (Objects.requireNonNull(firstNameInput.getText()).toString().trim().isEmpty()) {
            firstNameInput.setError("First name is required");
            isValid = false;
        }

        // Last name validation
        if (Objects.requireNonNull(lastNameInput.getText()).toString().trim().isEmpty()) {
            lastNameInput.setError("Last name is required");
            isValid = false;
        }

        // Email validation
        String email = Objects.requireNonNull(emailInput.getText()).toString().trim();
        if (email.isEmpty()) {
            emailLayout.setError("Email is required");
            isValid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) { //looked up
            emailLayout.setError("Must be a valid email");
            isValid = false;
        } else {
            emailLayout.setError(null); 
        }

        // Zipcode validation
        String zipcode = Objects.requireNonNull(zipcodeInput.getText()).toString().trim();
        if (zipcode.isEmpty()) {
            zipcodeLayout.setError("Zipcode is required");
            isValid = false;
        } else if (zipcode.length() != 5 || !zipcode.matches("\\d+")) {
            zipcodeLayout.setError("Must be 5 digits");
            isValid = false;
        } else {
            zipcodeLayout.setError(null);
        }

        return isValid;
    }
}