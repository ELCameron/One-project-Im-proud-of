package com.example.myapplication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity4 extends AppCompatActivity {

    private HashMap<String, boolean[]> checkedStates = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        // Initialize RecyclerView
        RecyclerView recyclerView = findViewById(R.id.savedListsRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        // Load saved lists
        Map<String, ?> allLists = getSharedPreferences("ShoppingLists", MODE_PRIVATE).getAll();
        ArrayList<String> savedLists = new ArrayList<>();

        for (Map.Entry<String, ?> entry : allLists.entrySet()) {
            String listName = entry.getKey();
            int itemCount = entry.getValue().toString().split(",").length;
            savedLists.add(listName + " (" + itemCount + " items)");

            // Initialize checked states for each list
            checkedStates.put(listName, new boolean[itemCount]);
        }

        // Set up adapter
        recyclerView.setAdapter(new RecyclerView.Adapter() {
            @NonNull
            @Override
            public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext())
                        .inflate(android.R.layout.simple_list_item_1, parent, false);
                return new RecyclerView.ViewHolder(view) {};
            }

            @Override
            public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
                TextView textView = (TextView) holder.itemView;
                String listInfo = savedLists.get(position);
                textView.setText(listInfo);

                holder.itemView.setOnClickListener(v -> {
                    String listName = listInfo.substring(0, listInfo.indexOf(" ("));
                    showListDialog(listName, allLists.get(listName).toString());
                });
            }

            @Override
            public int getItemCount() {
                return savedLists.size();
            }
        });

        // Back button
        findViewById(R.id.backButton).setOnClickListener(v -> finish());
    }

    private void showListDialog(String listName, String itemsString) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(listName);

        String[] items = itemsString.split(",");
        boolean[] checkedItems = checkedStates.get(listName);

        // Create checkboxes for each item
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 20, 50, 20);

        for (int i = 0; i < items.length; i++) {
            CheckBox checkBox = new CheckBox(this);
            checkBox.setText(items[i].trim());
            checkBox.setChecked(checkedItems[i]);
            checkBox.setTextSize(16);

            final int position = i;
            checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                checkedItems[position] = isChecked;
            });

            layout.addView(checkBox);
        }

        builder.setView(layout);
        builder.setPositiveButton("Save", (dialog, which) -> {
            Toast.makeText(this, "Selections saved for " + listName, Toast.LENGTH_SHORT).show();
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
}