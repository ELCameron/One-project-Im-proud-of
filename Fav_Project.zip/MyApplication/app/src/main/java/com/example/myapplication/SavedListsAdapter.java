package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
//I got a lot of help on this part from my cousin doing computer math in grad school
public class SavedListsAdapter extends RecyclerView.Adapter<SavedListsAdapter.ViewHolder> {

    private final List<String> savedLists;

    public SavedListsAdapter(List<String> savedLists) {
        this.savedLists = savedLists;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(android.R.layout.simple_list_item_1, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(savedLists.get(position));
    }

    @Override
    public int getItemCount() {
        return savedLists.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView textView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(android.R.id.text1);
            textView.setTextSize(18);
            textView.setTextColor(0xFF1B5E20);
        }

        public void bind(String listInfo) {
            textView.setText(listInfo);
            itemView.setOnClickListener(v -> {
                // Add click handling later
            });
        }
    }
}